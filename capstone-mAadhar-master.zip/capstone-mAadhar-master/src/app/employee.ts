export class Employee {
    id: number;
    firstName: string;
    lastName: string;
    dob: string;
    address: string;
    emailId: string;
    mobileNo: string;
    gender: string;
    }
