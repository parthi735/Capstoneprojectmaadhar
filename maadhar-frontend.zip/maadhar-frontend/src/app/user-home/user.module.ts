export class UserModel{
    citizenId:number=0;
    name:string='';
    dob:string='';
    mobileno:string='';
    address:string='';
    emailid:string='';
    gender:string='';
    status:string='';

}